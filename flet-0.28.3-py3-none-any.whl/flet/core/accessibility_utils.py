"""
iOS VoiceOver Accessibility Utilities for Flet

This module provides utility functions to optimize Flet apps for iOS VoiceOver,
specifically addressing issues with empty accessibility nodes in complex views.
"""

from typing import Optional, Any
from flet.core.control import Control


class AccessibilityOptimizer:
    """
    Utility class for optimizing Flet controls for iOS VoiceOver accessibility.
    """
    
    @staticmethod
    def should_exclude_from_semantics(control: Control) -> bool:
        """
        Determine if a control should be excluded from the accessibility tree
        to prevent empty accessibility nodes in iOS VoiceOver.
        
        Args:
            control: The control to evaluate
            
        Returns:
            True if the control should be excluded from semantics
        """
        if not control:
            return False
            
        control_name = control._get_control_name().lower()
        
        # Layout containers should generally be excluded unless they have semantic meaning
        if control_name in ['container', 'column', 'row']:
            return AccessibilityOptimizer._is_layout_only_container(control)
            
        # Other controls should remain in accessibility tree by default
        return False
    
    @staticmethod
    def _is_layout_only_container(control: Control) -> bool:
        """
        Check if a container/column/row serves purely layout purposes
        and should be excluded from accessibility tree.
        """
        # For containers
        if hasattr(control, 'on_click') and control.on_click is not None:
            return False  # Interactive containers should remain accessible
            
        if hasattr(control, 'url') and control.url is not None:
            return False  # Link containers should remain accessible
            
        if hasattr(control, 'bgcolor') and control.bgcolor is not None:
            return False  # Visually distinct containers may have semantic meaning
            
        # For containers with content, check if they add semantic value
        if hasattr(control, 'content') and control.content is not None:
            return True  # Layout containers with content can be excluded
            
        # For columns/rows with controls
        if hasattr(control, 'controls') and control.controls and len(control.controls) > 0:
            return True  # Layout containers with child controls can be excluded
            
        return False
    
    @staticmethod
    def optimize_semantics_for_ios(control: Control) -> None:
        """
        Apply iOS VoiceOver optimizations to a control and its children.
        
        This function:
        1. Excludes layout-only containers from accessibility tree
        2. Ensures interactive elements remain accessible
        3. Optimizes semantic hierarchy for VoiceOver
        """
        if not control:
            return
            
        # Check if this control should be excluded from semantics
        if AccessibilityOptimizer.should_exclude_from_semantics(control):
            control._set_attr("excludeSemantics", True)
        
        # Recursively optimize children
        if hasattr(control, '_get_children'):
            children = control._get_children()
            if children:
                for child in children:
                    AccessibilityOptimizer.optimize_semantics_for_ios(child)
    
    @staticmethod
    def create_accessible_button_group(buttons: list, group_label: Optional[str] = None) -> Control:
        """
        Create an accessible group of buttons that works well with iOS VoiceOver.
        
        Args:
            buttons: List of button controls
            group_label: Optional label for the button group
            
        Returns:
            A properly configured container with the buttons
        """
        from flet.core.column import Column
        from flet.core.semantics import Semantics
        
        # Create a column for the buttons
        button_column = Column(
            controls=buttons,
            tight=True,
            spacing=10
        )
        
        # Wrap in semantics for better VoiceOver navigation
        if group_label:
            return Semantics(
                content=button_column,
                label=group_label,
                container=False,  # Don't block individual button access
                focusable=False,  # Allow children to be focused
            )
        else:
            # No semantic wrapper needed, just exclude the column from semantics
            button_column._set_attr("excludeSemantics", True)
            return button_column